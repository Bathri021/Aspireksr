﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebForm
{
    public partial class TestForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = new HttpCookie("userInfo");
            cookie.Value = txtFirstName.Text;
            Response.Cookies["userInfo"].Expires = DateTime.Now.AddHours(1);
            Response.Cookies.Add(cookie);
        }

        protected void createQueryString(object sender, EventArgs e)
        {
            Response.Redirect("ResultForm.aspx?firstname="+txtFirstName.Text+"&lastname="+txtLastName.Text);
        }

        protected void createCookie(object sender, EventArgs e)
        {
            Response.Redirect("ResultForm.aspx");
        }
    }
}