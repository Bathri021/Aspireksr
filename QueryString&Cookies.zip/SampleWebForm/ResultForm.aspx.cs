﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebForm
{
    public partial class ResultForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string firstname = Request.QueryString["firstname"];
            string lastname = Request.QueryString["lastname"];
            lblResult.Text ="Query String : Welcome " +firstname+" "+lastname;

            string cookie_val = Request.Cookies["userInfo"].Value;
            lblCookie.Text = "Cookie : "+cookie_val;
        }
    }
}